import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class RegisterTest {

    @Test
    void testValidRegistration() {
        register Register = new register();
        boolean result = Register.register(
                "Miradi",
                "Ndibu",
                "Mi_Nd",
                "Tsh354@",
                "+27812345678"
        );
        Assertions.assertTrue(result);
        Assertions.assertEquals("Miradi", register.getFirstName());
        Assertions.assertEquals("Ndibu", register.getLastName());
        Assertions.assertEquals("Mi_Nd", register.getUsername());
        Assertions.assertEquals("Tsh354@", register.getPassword());
        Assertions.assertEquals("+27812345678", register.getCellPhoneNumber());
    }

    @Test
    void testInvalidUsername() {
        register Register = new register();
        boolean result = Register.register(
                "Bob",
                "Brown",
                "bob123", // no underscore
                "B0b@Secure",
                "+27812345678"
        );
        Assertions.assertFalse(result);
    }

    @Test
    void testInvalidPassword() {
        register Register = new register();
        boolean result = Register.register(
                "Carol",
                "White",
                "carol_1",
                "password", // invalid: no upper, digit, special
                "+27812345678"
        );
        Assertions.assertFalse(result);
    }

    @Test
    void testInvalidPhoneNumber() {
        register Register = new register();
        boolean result = Register.register(
                "Dan",
                "Green",
                "dan_1",
                "D@n123456",
                "0812345678" // invalid format (missing +27)
        );
        Assertions.assertFalse(result);
    }

}