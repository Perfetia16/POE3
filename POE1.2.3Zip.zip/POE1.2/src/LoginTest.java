import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.Assert.assertEquals;

public class LoginTest {

    private Login login;

    @BeforeEach
    void setup() {
        login = new Login();
        login.register("Miradi", "Ndibu", "Mi_Nd", "Tsh354@", "+27812345678");
    }

    @Test
    void testSuccessfulLogin() {
          assertEquals("Mi_Nd", "Tsh354@");

    }

    @Test
    void testLoginWithWrongUsername() {
         assertEquals("wrong_user", "Tsh354@");

    }

    @Test
    void testLoginWithWrongPassword() {
         assertEquals ("Mi_Nd", "wrongpass");

    }


}
