import javax.swing.JOptionPane;
import java.io.*;
import java.util.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException; // Import ParseException

public class Message {
    private static int messageCounter = 0;
    private static final int SIZE = 100;
    private static Message[] messages = new Message[SIZE];
    private static int currentMessageCount = 0;
    private static final String JSON_FILE_PATH = "messages.json"; // Define the file path
    private String text;
    private String hash;
    private String id;
    private String recipient;
    private String status;
    public Message() {
        loadMessagesFromJsonStore();
    }

    private void saveMessagesToJsonStore() {
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < currentMessageCount; i++) {
            JSONObject jsonMessage = new JSONObject();
            jsonMessage.put("id", messages[i].id);
            jsonMessage.put("recipient", messages[i].recipient);
            jsonMessage.put("text", messages[i].text);
            jsonMessage.put("hash", messages[i].hash);
            jsonMessage.put("status", messages[i].status);
            jsonArray.add(jsonMessage);
        }

        try (FileWriter file = new FileWriter(JSON_FILE_PATH)) {
            file.write(jsonArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving messages: " + e.getMessage(), "File Save Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadMessagesFromJsonStore() {
        currentMessageCount = 0;
        messageCounter = 0;
        JSONParser parser = new JSONParser();

        try (FileReader reader = new FileReader(JSON_FILE_PATH)) {
            Object obj = parser.parse(reader);
            JSONArray jsonArray = (JSONArray) obj;

            for (Object o : jsonArray) {
                if (currentMessageCount >= SIZE) {
                    System.err.println("Array is full. Could not load all messages from JSON store.");
                    break;
                }
                JSONObject jsonMessage = (JSONObject) o;
                String id = (String) jsonMessage.get("id");
                String recipient = (String) jsonMessage.get("recipient");
                String text = (String) jsonMessage.get("text");
                String hash = (String) jsonMessage.get("hash");
                String status = (String) jsonMessage.get("status");

                if (id != null && recipient != null && text != null && hash != null && status != null) {
                    messages[currentMessageCount] = new Message();
                    currentMessageCount++;

                    try {
                        int currentId = Integer.parseInt(id);
                        if (currentId > messageCounter) {
                            messageCounter = currentId;
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid message ID format encountered during loading: " + id);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            // File not found, likely first run, or no messages saved yet.
            // No need to show an error dialog for this specific case.
            System.out.println("No existing messages.json found. Starting fresh.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading messages: " + e.getMessage(), "File Load Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Error parsing messages.json: " + e.getMessage(), "JSON Parse Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    public void menu() {
        boolean running = true;
        while (running) {
            String option = JOptionPane.showInputDialog(
                    "Welcome to QuickChat\n" +
                            "Choose an option:" +
                            "\n1. Send Message" +
                            "\n2. Search Message by Phone Number" +
                            "\n3. View Messages" +
                            "\n4. Search Message by Hash" +
                            "\n5. View Longest Message" +
                            "\n6. Delete Message by Phone Number" +
                            "\n7. Quit"
            );

            if ("1".equals(option)) {
                String msgCountStr = JOptionPane.showInputDialog("How many messages do you want to send?");
                try {
                    int msgCount = Integer.parseInt(msgCountStr);
                    for (int i = 0; i < msgCount; i++) {
                        sendMessage();
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number for message count.");
                }
            } else if ("2".equals(option)) {
                searchMessageByPhoneNumber();
            } else if ("3".equals(option)) {
                printMessages();
            } else if ("4".equals(option)) {
                searchMessageByHash();
            } else if ("5".equals(option)) {
                viewLongestMessage();
            } else if ("6".equals(option)) {
                deleteMessageByPhoneNumber();
            } else if ("7".equals(option)) {
                running = false;
                JOptionPane.showMessageDialog(null, "Goodbye!");
            }
            else {
                JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    public void sendMessage() {
        if (currentMessageCount >= SIZE) {
            JOptionPane.showMessageDialog(null, "Message storage full. Cannot send new messages.");
            return;
        }

        String recipient;
        do {
            recipient = JOptionPane.showInputDialog("Enter recipient's number must start with +27 :");
            if (recipient == null) {
                return;
            }
            if (!recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid recipient number format. Must start with '+' and be 10 or more digits long.");
            }
        } while (!recipient.matches("^\\+27\\d{9}$"));

        String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");

        if (messageText == null || messageText.length() > 250) {
            JOptionPane.showMessageDialog(null, "Message exceeds 250 characters or was cancelled. Please reduce size.");
            return;
        }

        messageCounter++;
        String messageID = String.format("%010d", messageCounter);
        String hash = createMessageHash(messageID, messageText);

        String[] options = {"Send Message", "Disregard Message", "Store Message"};
        int choice = JOptionPane.showOptionDialog(null,
                "Choose action for this message:",
                "Message Options",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);

        String messageStatus = "";
        if (choice == 0) {
            messageStatus = "Sent";
            messages[currentMessageCount] = new Message();
            currentMessageCount++;
            saveMessagesToJsonStore();
            JOptionPane.showMessageDialog(null, "Message successfully sent.");
        } else if (choice == 2) {
            messageStatus = "Stored";
            messages[currentMessageCount] = new Message();
            currentMessageCount++;
            saveMessagesToJsonStore();
            JOptionPane.showMessageDialog(null, "Message successfully stored.");
        } else if (choice == 1) {
            JOptionPane.showMessageDialog(null, "Message disregarded.");
            messageCounter--;
        }
    }

    public String createMessageHash(String id, String msg) {
        String trimmedMsg = msg.trim();
        if (trimmedMsg.isEmpty()) {
            return id.substring(0, 2) + ":" + id.charAt(id.length() - 1);
        }
        String[] words = trimmedMsg.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();

        return id.substring(0, 2) + ":" + id.charAt(id.length() - 1) +
                firstWord + lastWord;
    }

    public void searchMessageByPhoneNumber() {
        loadMessagesFromJsonStore();

        String searchNumber;
        do {
            searchNumber = JOptionPane.showInputDialog("Enter recipient's phone number to search (e.g., +27123456789):");
            if (searchNumber == null) {
                return;
            }
            if (!searchNumber.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone number format. Must start with '+27' and be 12 digits long.");
            }
        } while (!searchNumber.matches("^\\+27\\d{9}$"));

        StringBuilder searchResults = new StringBuilder();
        int foundCount = 0;

        for (int i = 0; i < currentMessageCount; i++) {
            Message msg = messages[i];
            if (msg.recipient.equals(searchNumber)) {
                if (foundCount > 0) {
                    searchResults.append("\n\n");
                }
                searchResults.append("Status: ").append(msg.status).append("\n");
                searchResults.append("ID: ").append(msg.id).append("\n");
                searchResults.append("Hash: ").append(msg.hash).append("\n");
                searchResults.append("To: ").append(msg.recipient).append("\n");
                searchResults.append("Message: ").append(msg.text);
                foundCount++;
            }
        }

        if (foundCount > 0) {
            JOptionPane.showMessageDialog(null, "Message(s) found for " + searchNumber + ":\n\n" + searchResults.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No message found for phone number: " + searchNumber);
        }
    }

    public void printMessages() {
        loadMessagesFromJsonStore();
        if (currentMessageCount == 0) {
            JOptionPane.showMessageDialog(null, "No messages to show.");
        } else {
            StringBuilder outputMessages = new StringBuilder();
            for (int i = 0; i < currentMessageCount; i++) {
                Message msg = messages[i];
                if (i > 0) {
                    outputMessages.append("\n\n");
                }
                outputMessages.append("Status: ").append(msg.status).append("\n");
                outputMessages.append("ID: ").append(msg.id).append("\n");
                outputMessages.append("Hash: ").append(msg.hash).append("\n");
                outputMessages.append("To: ").append(msg.recipient).append("\n");
                outputMessages.append("Message: ").append(msg.text);
            }

            Object[] options = {"OK", "Delete All Messages"};
            int choice = JOptionPane.showOptionDialog(
                    null,
                    outputMessages.toString(),
                    "Your Stored Messages",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
            );

            if (choice == 1) {
                deleteAllMessages();
            }
        }
    }

    private void deleteAllMessages() {
        currentMessageCount = 0;
        messageCounter = 0;
        saveMessagesToJsonStore(); // Save an empty JSON array to clear the file
        JOptionPane.showMessageDialog(null, "All messages have been deleted.");
    }

    public void viewLongestMessage() {
        loadMessagesFromJsonStore();

        if (currentMessageCount == 0) {
            JOptionPane.showMessageDialog(null, "No messages available to determine the longest.");
            return;
        }

        Message longestMessage = null;
        int maxLength = -1;

        for (int i = 0; i < currentMessageCount; i++) {
            Message msg = messages[i];
            if (msg.text != null && msg.text.length() > maxLength) {
                maxLength = msg.text.length();
                longestMessage = msg;
            }
        }

        if (longestMessage != null) {
            String output = "Longest Message Found:\n\n" +
                    "Status: " + longestMessage.status + "\n" +
                    "ID: " + longestMessage.id + "\n" +
                    "Hash: " + longestMessage.hash + "\n" +
                    "To: " + longestMessage.recipient + "\n" +
                    "Message: " + longestMessage.text +
                    "\n\n(Length: " + maxLength + " characters)";
            JOptionPane.showMessageDialog(null, output);
        } else {
            JOptionPane.showMessageDialog(null, "Could not find the longest message.");
        }
    }

    public void searchMessageByHash() {
        loadMessagesFromJsonStore();

        if (currentMessageCount == 0) {
            JOptionPane.showMessageDialog(null, "No messages available to search by hash.");
            return;
        }

        String searchHash;
        do {
            searchHash = JOptionPane.showInputDialog("Enter message hash to search (e.g., 00:1HELLOWORLD):");
            if (searchHash == null) {
                return;
            }

            if (searchHash.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Message hash cannot be empty. Please enter a valid hash.");
            }
        } while (searchHash.trim().isEmpty());


        Message foundMessage = null;
        for (int i = 0; i < currentMessageCount; i++) {
            Message msg = messages[i];
            if (msg.hash.equals(searchHash)) { // Changed comparison to msg.hash
                foundMessage = msg;
                break;
            }
        }

        if (foundMessage != null) {
            String output = "Message Found (Hash: " + searchHash + "):\n\n" +
                    "Status: " + foundMessage.status + "\n" +
                    "ID: " + foundMessage.id + "\n" +
                    "Hash: " + foundMessage.hash + "\n" +
                    "To: " + foundMessage.recipient + "\n" +
                    "Message: " + foundMessage.text;
            JOptionPane.showMessageDialog(null, output);
        } else {
            JOptionPane.showMessageDialog(null, "No message found with hash: " + searchHash);
        }
    }

    public void deleteMessageByPhoneNumber() {
        loadMessagesFromJsonStore();

        if (currentMessageCount == 0) {
            JOptionPane.showMessageDialog(null, "No messages available to delete.");
            return;
        }

        String searchNumber;
        do {
            searchNumber = JOptionPane.showInputDialog("Enter recipient's phone number to find messages for deletion (e.g., +27123456789):");
            if (searchNumber == null) {
                return;
            }
            if (!searchNumber.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid phone number format. Must start with '+27' and be 12 digits long.");
            }
        } while (!searchNumber.matches("^\\+27\\d{9}$"));

        // Use a StringBuilder to display messages for deletion
        StringBuilder displayMessages = new StringBuilder();
        int matchingCount = 0;
        for (int i = 0; i < currentMessageCount; i++) {
            Message msg = messages[i];
            if (msg.recipient.equals(searchNumber)) {
                if (matchingCount > 0) {
                    displayMessages.append("\n\n");
                }
                displayMessages.append("ID: ").append(msg.id).append("\n");
                displayMessages.append("Status: ").append(msg.status).append("\n");
                displayMessages.append("Message: ").append(msg.text);
                matchingCount++;
            }
        }

        if (matchingCount == 0) {
            JOptionPane.showMessageDialog(null, "No messages found for phone number: " + searchNumber);
            return;
        }

        String messagesToShow = "Messages for " + searchNumber + ":\n\n" + displayMessages.toString() +
                "\n\nEnter the ID of the message to delete:";

        String idToDelete = JOptionPane.showInputDialog(null, messagesToShow);

        if (idToDelete == null) {
            return;
        }

        if (!idToDelete.matches("^\\d{10}$")) {
            JOptionPane.showMessageDialog(null, "Invalid message ID format. Deletion cancelled.");
            return;
        }

        int indexToDelete = -1;
        for (int i = 0; i < currentMessageCount; i++) {
            if (messages[i].id.equals(idToDelete)) {
                indexToDelete = i;
                break;
            }
        }

        if (indexToDelete != -1) {
            int confirm = JOptionPane.showConfirmDialog(null,
                    "Are you sure you want to delete message with ID: " + idToDelete + "?",
                    "Confirm Deletion", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                for (int i = indexToDelete; i < currentMessageCount - 1; i++) {
                    messages[i] = messages[i + 1];
                }
                messages[currentMessageCount - 1] = null; // Clear the last element
                currentMessageCount--;

                saveMessagesToJsonStore();
                JOptionPane.showMessageDialog(null, "Message with ID " + idToDelete + " has been successfully deleted.");
            } else {
                JOptionPane.showMessageDialog(null, "Message deletion cancelled.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "No message found with ID: " + idToDelete + " for the specified phone number.");
        }
    }


    static class chat {
        String id;
        String recipient;
        String text;
        String hash;
        String status;

        public chat(String id, String recipient, String text, String hash, String status) {
            this.id = id;
            this.recipient = recipient;
            this.text = text;
            this.hash = hash;
            this.status = status;
        }
    }
}