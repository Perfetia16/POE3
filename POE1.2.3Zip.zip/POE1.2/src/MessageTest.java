import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

public class MessageTest {

    private Message message;

    @BeforeEach
    public void setUp() {
        message = new Message();
    }

    @Test
    public void testCreateMessageHash_basic() {
        String id = "0000000010";
        String msg = "Hello world";
        String hash = message.createMessageHash(id, msg);
        assertEquals("00:0HELLOWORLD", hash);
    }

    @Test
    public void testCreateMessageHash_trimsWhitespace() {
        String id = "0000000009";
        String msg = "   spaced out message   ";
        String hash = message.createMessageHash(id, msg);
        assertEquals("00:9SPACEDMESSAGE", hash);
    }

    @Test
    public void testCreateMessageHash_emptyMessage() {
        String id = "0000000003";
        String msg = "    ";
        String hash = message.createMessageHash(id, msg);
        assertEquals("00:3", hash);
    }

    @Test
    public void testCreateMessageHash_singleWord() {
        String id = "0000000011";
        String msg = "onlyoneword";
        String hash = message.createMessageHash(id, msg);
        assertEquals("00:1ONLYONEWORDONLYONEWORD", hash);
    }

    @Test
    public void testSendMessage_storageLimitExceeded() throws Exception {
        // Use reflection to fill up the message storage
        Field currentMessageCountField = Message.class.getDeclaredField("currentMessageCount");
        currentMessageCountField.setAccessible(true);
        currentMessageCountField.set(null, 100); // SIZE is 100

        // Capture system output or behavior (if modified to support testability)
        assertDoesNotThrow(() -> {
            message.sendMessage(); // Should show a dialog about storage being full
        });

        // Reset for other tests
        currentMessageCountField.set(null, 0);
    }
}
