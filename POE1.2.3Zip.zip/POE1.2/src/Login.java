import javax.swing.*;

public class Login extends register {

    public boolean login() {
        for (int i = 0; i < 3; i++) {
            JOptionPane.showMessageDialog(null, "Welcome to login");
            String user = JOptionPane.showInputDialog("Enter your user name:");
            String password = JOptionPane.showInputDialog("Enter password:");

            if (user.equals(getUsername()) && password.equals(getPassword())) {
                JOptionPane.showMessageDialog(null, "Welcome," + getFirstName() + "!");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Incorrect login details. Attempts left:" + (2 - i));
            }
        }
        JOptionPane.showMessageDialog(null, "Too many attempts failed. Try later");
        return false;
    }
}