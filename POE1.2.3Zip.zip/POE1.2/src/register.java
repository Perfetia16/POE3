import javax.swing.*;

public class register {
    private static String firstName;
    private static String lastName;
    private static String username;
    private static String password;
    private static String cellPhoneNumber;


    public boolean register(String firstName, String lastName, String username, String password, String cellPhoneNumber) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;


        if (username.length() < 5 || !username.contains("_")) {
            JOptionPane.showMessageDialog(null, "Invalid username. Must be 5+ char and contain a _");
            return false;
        }


        if (!validatePassword(password)) {
            JOptionPane.showMessageDialog(null, "Invalid password. Must contain 8+ char");
            return false;
        }


        if (!cellPhoneNumber.matches("^\\+27\\d{9}$")) {

            JOptionPane.showMessageDialog(null, "Invalid phone number");
            return false;


        }


        return false;
    }



    private boolean validatePassword (String password) {


        return false;
    }
        public static String getFirstName() {
            return firstName;
        }
        public static String getLastName() {
            return lastName;
        }
        public static String getUsername() {
            return username;
        }
        public static String getPassword() {
            return password;
        }

        public static String getCellPhoneNumber() {
            return cellPhoneNumber;
        }

        public String registerDetails () {
            return "firstname:" + firstName + ",lastname:" + lastName + ",username:" + username + ",password:" + password + ",phonenumber:" + cellPhoneNumber;
        }
    }
